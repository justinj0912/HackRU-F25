
  # Login and Signup Pages

  This is a code bundle for Login and Signup Pages. The original project is available at https://www.figma.com/design/UaMzJrdojsvyHIxImWWGOS/Login-and-Signup-Pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  